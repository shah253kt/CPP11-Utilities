# C++11 Utilities
This library was made specifically for providing some utilities to embedded platforms.

## Disclaimer
I have only tested this using ESP32. I cannot guarantee that it will work on other devices.