#pragma once

namespace MathUtilities
{
    [[nodiscard]] bool equals(float a, float b, float epsilon = 0.001f);
}
